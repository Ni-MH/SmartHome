<template>
  <div class="page">
    <h1>404: Page not found 😲</h1>
    <h2>
      <router-link to="/">
        <q-icon name="home"></q-icon>
        Go home
      </router-link>
    </h2>
  </div>
</template>
