<template src="../../CHANGELOG.html">
</template>


<script>
  export default {
    name: "Changelog",

    data() {
      return {
      };
    },

    methods: {
    }
  };
</script>


<style lang="stylus" scoped>
  h2
    font-size 1.4rem
    font-weight bold
    border-bottom 1px solid #c2c0c0
    line-height 1.5rem
</style>
